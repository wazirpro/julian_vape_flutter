
import 'package:flutter/material.dart';

void main() => runApp(JulianVapeApp());

class JulianVapeApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Julian Tobacco & Vape',
      theme: ThemeData(primarySwatch: Colors.blueGrey),
      home: Scaffold(
        appBar: AppBar(title: Text('Julian Tobacco & Vape')),
        body: Center(child: Text('Welcome to Julian Vape Shop!', style: TextStyle(fontSize: 20))),
      ),
    );
  }
}
